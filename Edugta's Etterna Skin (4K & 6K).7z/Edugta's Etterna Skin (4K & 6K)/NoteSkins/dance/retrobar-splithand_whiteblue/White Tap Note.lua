return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_White', 'tap note' );
	Frames = Sprite.LinearFrames( 4, 1 );
};