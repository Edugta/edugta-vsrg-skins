return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_Blue', 'tap note' );
	Frames = Sprite.LinearFrames( 4, 1 );
};